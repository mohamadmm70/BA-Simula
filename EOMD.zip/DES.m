clc
clear

% This ode45 equation solver solves equations of motion which are presented
% in EOM function, note that the 1*12 matrix here indicates initial
% conditions and its arrays respectively are 1= Surge , 2= Surge
% velocity , 3= Sway , 4= Sway velocity , 5= Heave , 6= Heave velocity , 7=
% Pitch , 8= Pitch velociy , 9= Roll , 10= Roll velocity , 11= Yaw and 12=
% Yaw velocity initial conditions

[T,S] = ode45(@EOMD2,0:1:300,[15 0 0 0 0 0 0 0 0 0 0 0]);

subplot(231), plot(T,S(:,1));
subplot(232), plot(T,S(:,3));
subplot(233), plot(T,S(:,5));
subplot(234), plot(T,S(:,7));
subplot(235), plot(T,S(:,9));
subplot(236), plot(T,S(:,11));