function [Ficrush,Fiflex]=F_ice(x,t)


R_sai=[cos(x(11)) sin(x(11)) 0;-sin(x(11)) cos(x(11)) 0;0 0 1];
R_fi=[cos(x(9)) 0 -sin(x(9));0 1 0;sin(x(9)) 0 cos(x(9))];
R_tet=[1 0 0;0 cos(x(7)) sin(x(7));0 -sin(x(7)) cos(x(7))];
R_x=[cos(x(9))*cos(x(11)),cos(x(9))*sin(x(11)),-sin(x(9))];
R_y=[ cos(x(11))*sin(x(9))*sin(x(7))-cos(x(7))*sin(x(11)),cos(x(11))*cos(x(7))+sin(x(9))*sin(x(11))*sin(x(7)),cos(x(9))*sin(x(7))];
R_z=[ sin(x(11))*sin(x(7))+cos(x(11))*cos(x(7))*sin(x(9)),cos(x(7))*sin(x(9))*sin(x(11))-cos(x(11))*sin(x(7)),cos(x(9))*cos(x(7))];


if (R_z*[x(1);x(3);x(5)])>=-10 && (R_z*[x(1);x(3);x(5)])<=4
    D=6.5;
elseif (R_z*[x(1);x(3);x(5)])>4 && (R_z*[x(1);x(3);x(5)])<12
    D=6.5+(0.3625.*((R_z*[x(1);x(3);x(5)])-4));
elseif (R_z*[x(1);x(3);x(5)])>=12 && (R_z*[x(1);x(3);x(5)])<=120
    D=9.4;
else
    D=6.5;
end

h = 1; sigma_c = 1.8e6; 

k1 = 0.9;
k2 = 0.5;
k3 = sqrt(1+(5*h)/D);


P = k1*k2*k3*h*D*sigma_c;

%% Flexural

g = 9.81; E = 7e9; sigma_f = 0.5e6; miu_s = 0.15; miu_i = 0.05; v = 0.3; rho = 1044.2; rho_i = 907.5; pros = 0.3; hr = 4; 
alfa = 52; teta = 40; phi = 45; c = 0; omega_n = 0.25;

zeta = (sind(alfa)+miu_s*cosd(alfa))/(cosd(alfa)-miu_s*sind(alfa));

L_c = ((E*h^3)/(12*rho*g*(1-v^2)))^(1/4);

HB = 0.68*zeta*sigma_f*(((rho*g*h^5)/E)^(1/4))*(D+(pi^2*L_c)/4);

HP = D*hr^2*miu_i*rho_i*g*(1-pros)*(1-(tand(teta)/tand(alfa)))^2*(1/(2*tand(teta)));

P1 = 0.5*miu_i*(miu_i+miu_s)*rho_i*g*(1-pros)*hr^2*sind(alfa)*(cotd(teta)-cotd(alfa))*(1-(tand(teta)/tand(alfa)))+...
    0.5*(miu_i+miu_s)*rho_i*g*(1-pros)*hr^2*(cosd(alfa)/tand(alfa))*(1-(tand(teta)/tand(alfa)))+hr*h*rho_i*g*((sind(alfa)+miu_s*cosd(alfa))/sind(alfa));

HR = D*P1*(1/(cosd(alfa)-miu_s*sind(alfa)));

HL = 0.5*D*hr^2*rho_i*g*(1-pros)*zeta*(cotd(teta)-cotd(alfa))*(1-(tand(teta)/tand(alfa)))+...
    0.5*D*hr^2*rho_i*g*(1-pros)*zeta*tand(phi)*(1-(tand(teta)/tand(alfa)))^2+zeta*c*D*hr*(1-(tand(teta)/tand(alfa)));

HT = 1.5*D*h^2*rho_i*g*(cosd(alfa)/(sind(alfa)-miu_s*cosd(alfa)));

l_c = D+(pi^2/4)*L_c;


FH = (HB+HP+HR+HL+HT)/(1-(HB/(sigma_f*l_c*h)));

Ficrush = R_sai*R_fi*R_tet*[P*(0.75+0.25*sin(omega_n*t));0;0];

Fiflex = R_sai*R_fi*R_tet*[FH*(0.75+0.25*sin(omega_n*t));0;0];



