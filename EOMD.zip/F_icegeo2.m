function [FI, MIce, p, q]=F_icegeo2(x,p,q,t)



    
phi = (45-90); h = 0.8; g = 9.81; E = 7e9; rho = 1044.2;  v = 0.3; Vicex = -0.02; Vicey = 0; cl = 0.1; cv = -0.2; sigma_c = 2.3e6;
miu_i = 0.15;




R_sai=[cos(x(11)) sin(x(11)) 0;-sin(x(11)) cos(x(11)) 0;0 0 1];
R_fi=[cos(x(9)) 0 -sin(x(9));0 1 0;sin(x(9)) 0 cos(x(9))];
R_tet=[1 0 0;0 cos(x(7)) sin(x(7));0 -sin(x(7)) cos(x(7))];
R_x=[cos(x(9))*cos(x(11)),cos(x(9))*sin(x(11)),-sin(x(9))];
R_y=[ cos(x(11))*sin(x(9))*sin(x(7))-cos(x(7))*sin(x(11)),cos(x(11))*cos(x(7))+sin(x(9))*sin(x(11))*sin(x(7)),cos(x(9))*sin(x(7))];
R_z=[ sin(x(11))*sin(x(7))+cos(x(11))*cos(x(7))*sin(x(9)),cos(x(7))*sin(x(9))*sin(x(11))-cos(x(11))*sin(x(7)),cos(x(9))*cos(x(7))];


if (R_z*[x(1);x(3);x(5)])>=-10 && (R_z*[x(1);x(3);x(5)])<=4
    D=6.5;
elseif (R_z*[x(1);x(3);x(5)])>4 && (R_z*[x(1);x(3);x(5)])<12
    D=6.5+(0.3625.*((R_z*[x(1);x(3);x(5)])-4));
elseif (R_z*[x(1);x(3);x(5)])>=12 && (R_z*[x(1);x(3);x(5)])<=120
    D=9.4;
else
    D=6.5;
end


xx = R_x*[x(1);x(3);x(5)];
y = R_y*[x(1);x(3);x(5)];
ZZ = R_z*[x(1);x(3);x(5)];
vx  = R_x*[x(2);x(4);x(6)];
vy = R_y*[x(2);x(4);x(6)];
r = D/2;
th = 0:pi/50:2*pi;  
xunit = r * cos(th) + xx;
yunit = r * sin(th) + y;


[xi,yi] = polyxpoly(p,q,xunit,yunit,'unique');

pq = [p q];
xy = [xi yi];
 L = ((E*h^3)/(12*(1-v^2)*rho*g))^(1/4);

for i = 1: length(yi)
    
%     [val,idx]=min(sqrt((q-yi(i)).^2+(p-xi(i)).^2));
distances = sqrt((p-xi(i)).^2 + (q-yi(i)).^2);
              [val,idx] = min(distances);
%                AA = exist('idx');
               
% if AA==1      
    id(i)= idx;
% else 
%     FI = [0;0;0];
%     return
% end
end

AA = exist('idx');          
if AA==1 && length(unique(id,'stable'))>=2
id = sort(id);

for j = 1:length(id)-1
[in,on] = inpolygon(p(id(j):id(j+1)),q(id(j):id(j+1)),xunit,yunit);
 if sum(in)>2 
    Lh(j) = sqrt((p(id(j+1))-p(id(j)))^2 + (q(id(j+1))-q(id(j)))^2);
    Lh(Lh==0)=[];
    pmidl(j)= ((max(p(id(j+1)),p(id(j)))-min(p(id(j+1)),p(id(j))))/2)+ min(p(id(j+1)),p(id(j)));
    pcen(j) = (p(id(j+1))+p(id(j)))/2;
    pcen(pcen==0)=[];
     qcen(j) = (q(id(j+1))+q(id(j)))/2;
     qcen(qcen==0)=[];
     pmidl=unique(pmidl,'stable');
     pmidl(pmidl==0)=[];
    qmidl(j)= ((max(q(id(j+1)),q(id(j)))-min(q(id(j+1)),q(id(j))))/2)+ min(q(id(j+1)),q(id(j)));
     qmidl = unique(qmidl,'stable');
     qmidl(qmidl==0)=[];
     pqmidl = [pmidl' qmidl'];
    cx = x(1)+r.*(pmidl-x(1))./sqrt((pmidl-x(1)).^2+(qmidl-x(3)).^2);
    cy = x(3)+r.*(qmidl-x(3))./sqrt((pmidl-x(1)).^2+(qmidl-x(3)).^2);
    azi = acosd((cx-x(1))./r);
    Vreln = vx .* sind(azi) + vy * cosd(azi) - Vicex;
    Vrelt = vy .* sind(azi) + vx * cosd(azi) - Vicey;
%     R = cl * L *(1+cv*Vreln);
    
    for m = 1:length(p(id(j):id(j+1)))-2
        distance = GetPointLineDistance(p(id(j)+m),q(id(j)+m),p(id(j)),q(id(j)),p(id(j+1)),q(id(j+1)));
        dist(m)=distance;
    end
    Ld(j) = max(dist);
    Ld(Ld==0)=[];
%  else
%      FI = [0;0;0];
% 
%      
%  end
for n = 1:length(Lh)
    xarc(n,:) = Lh(n)/2 * cos(th) + pcen(n);
     yarc(n,:)= Lh(n)/2 * sin(th) +  qcen(n);
    end
 
   AB = exist('Ld'); 
  AC = exist('Lh');
 if AB==1 && AC==1
%      Ld = zeros(1,j);
%      Lh = zeros(1,j);
%  end
 for k = 1:length(Ld)
     if Ld(k)* tand(phi)<= h
         Acr(k) = 0.5 * Lh(k) * (Ld(k)/cosd(phi));
     else
         Acr(k) = 0.5 * (Lh(k)+Lh(k)*((Ld(k)-(h/tand(phi)))/Ld(k)));
     end
 end
 ins(j) = sum(in); 
 
% end

    

F_cr = sigma_c * Acr;
F_cr(F_cr==0)=[];
% f_H = (miu_i *F_cr.* Vrelt)./sqrt(Vrelt.^2+Vreln.^2);
f_V = (miu_i *F_cr.* Vreln)./sqrt(Vrelt.^2+Vreln.^2);

F_H = sum( F_cr * sind(phi) + f_V * cosd(phi));
F_V = sum(F_cr * cosd(phi) - f_V * sind(phi));

FI=R_sai*R_fi*R_tet*[F_H;0;F_V];

for b = 1:size(xarc,1)
    [xb,yb] = polyxpoly(p,q,xarc(b,:),yarc(b,:),'unique');
    xa(b,:)=[xb(1),xb(end)]';
    ya(b,:)=[yb(1),yb(end)]';
end

for z = 1: size(xa,1)
%     for o = 1: size(xa,2)
%     [val,idx]=min(sqrt((q-yi(i)).^2+(p-xi(i)).^2));
distances1 = sqrt((p-xa(z,:)).^2 + (q-ya(z,:)).^2);
              [val,indx] = min(distances1);
     ind(z,:)= indx;
     
     G = [p(ind(z,1)) p(ind(z,2));q(ind(z,1)) q(ind(z,2))]; % p - this is our points p1 & p2, p =[x1,x2;y1,y2];
%     r = 7;          % r - radius
%        % Finding the coordinates of the centers of circles
%      % xy = [x1, y1; x2, y2]
%       a = sym('a',[2,1],'real');
%         eqs = [1,1]*(G - repmat(a(:),1,2)).^2 - R(z)^2;
%         sol = vpasolve(eqs,a);
%       ss = struct2cell(sol);
%      xy = double([ss{:}]);
%          xy = circ_cent(G(1,:),G(2,:),R(z));
    % example: The arc of a circle with center at xy(1,:)
%      v = xy(1,:);
       v = [pcen(z),qcen(z)];
     p1 = G - v(:);
     alp = atand(p1(2,:)./p1(1,:));
    alp = alp + 180*(p1(1,:) < 0 & p1(2,:) > 0) - 180*(p1(1,:) < 0 & p1(2,:) < 0);
    asort = sort(alp);
    zhi = linspace(asort(1),asort(2),100)';
      %figure
      xrep(:,z) = Lh(z)/2*cosd(zhi) + v(1);
      yrep(:,z) = Lh(z)/2*sind(zhi) + v(2);
      
%       xrep = fliplr(xrep);
%        yrep = fliplr(yrep);
     %plot(R(z)*cosd(phi) + v(1),R(z)*sind(phi) + v(2),'-b',v(1),v(2),'ok')
       %grid on

end

% for z= 1:3
%      pnew = [p(1:ind(z,1))', xrep(:,z)', p(ind(z,2):end)'];
%      p = pnew';
%      qnew = [q(1:ind(z,1))', yrep(:,z)', q(ind(z,2):end)'];
%      q = qnew';
%      
% end

% w = 1;
% while w <= z-1
%     pnew = [p(1:ind(w,1))', xrep(:,w)', p(ind(w,2):p(1:ind(w+1,1)))'];
%     qnew(w,:) = [q(1:ind(w,1))', yrep(:,w)', q(ind(w,2):q(1:ind(w+1,1)))'];
%     w = w + 1;
%     pfin = p(ind(z,2):end)';
%     qfin = q(ind(z,2):end)';

%first input
% a=[0 1]; %P1
% b=[1 0]; %P2
% r=1;     %radius
%next solution
% end

%  pp = [pnew,pfin];
%  qq = [qnew,qfin];

ind = sort(ind,2);

for z=1: size(xa,1)
    
   xrepNew = interp1((1:numel(xrep(:,z))), xrep(:,z), linspace(1, numel(xrep(:,z)), numel(p(ind(z,1):ind(z,2)))), 'linear')';
   yrepNew = interp1((1:numel(yrep(:,z))), yrep(:,z), linspace(1, numel(yrep(:,z)), numel(q(ind(z,1):ind(z,2)))), 'linear')';
   p(ind(z,1):ind(z,2))=flip(xrepNew);
   q(ind(z,1):ind(z,2))=flip(yrepNew);
end
else
    FI = [0;0;0];
 end
 else
    FI = [0;0;0];
    
 end

end
else
    FI = [0;0;0];
    
end

% p = p + Vicex * t;
% q = q + Vicex * t;

MIce=cross([0;0;78-ZZ],FI);
% else
% p = p;
%     q = q;
% end