clc
clear


h = 1; sigma_c = 1.8e6; D = 14.2;

k1 = 0.9;
k2 = 0.5;
k3 = sqrt(1+(5*h)/D);


P = k1*k2*k3*h*D*sigma_c;

%% Flexural

g = 9.81; E = 7e9; sigma_f = 0.5e6; miu_s = 0.15; miu_i = 0.05; v = 0.3; rho = 1044.2; rho_i = 907.5; pros = 0.3; hr = 4; 
alfa = 52; teta = 40; phi = 45; c = 0; omega_n = 0.25;

zeta = (sind(alfa)+miu_s*cosd(alfa))/(cosd(alfa)-miu_s*sind(alfa));

L_c = ((E*h^3)/(12*rho*g*(1-v^2)))^(1/4);

HB = 0.68*zeta*sigma_f*(((rho*g*h^5)/E)^(1/4))*(D+(pi^2*L_c)/4);

HP = D*hr^2*miu_i*rho_i*g*(1-pros)*(1-(tand(teta)/tand(alfa)))^2*(1/(2*tand(teta)));

P1 = 0.5*miu_i*(miu_i+miu_s)*rho_i*g*(1-pros)*hr^2*sind(alfa)*(cotd(teta)-cotd(alfa))*(1-(tand(teta)/tand(alfa)))+...
    0.5*(miu_i+miu_s)*rho_i*g*(1-pros)*hr^2*(cosd(alfa)/tand(alfa))*(1-(tand(teta)/tand(alfa)))+hr*h*rho_i*g*((sind(alfa)+miu_s*cosd(alfa))/sind(alfa));

HR = D*P1*(1/(cosd(alfa)-miu_s*sind(alfa)));

HL = 0.5*D*hr^2*rho_i*g*(1-pros)*zeta*(cotd(teta)-cotd(alfa))*(1-(tand(teta)/tand(alfa)))+...
    0.5*D*hr^2*rho_i*g*(1-pros)*zeta*tand(phi)*(1-(tand(teta)/tand(alfa)))^2+zeta*c*D*hr*(1-(tand(teta)/tand(alfa)));

HT = 1.5*D*h^2*rho_i*g*(cosd(alfa)/(sind(alfa)-miu_s*cosd(alfa)));

l_c = D+(pi^2/4)*L_c;


FH = (HB+HP+HR+HL+HT)/(1-(HB/(sigma_f*l_c*h)));

% sigma_f1 = (FH/(l_c*h))+sigma_f;
% 
% FH1 = (HB+HP+HR+HL+HT)/(1-(HB/(sigma_f1*l_c*h)));